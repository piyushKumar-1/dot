{-# OPTIONS_GHC -Wunused-imports #-}
module CodeActionRedundant where
import Data.List
main :: IO ()
main = putStrLn "hello"
