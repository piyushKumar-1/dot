import Data.Text
foo = pack "I'm a Text"
main = putStrLn "hello"
