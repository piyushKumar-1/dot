main :: IO ()
main = when True $ putStrLn "hello"