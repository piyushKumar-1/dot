module Foo (module Bar) where

import Bar
