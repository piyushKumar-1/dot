import Data.Text
foo = pack "I'm a Text"