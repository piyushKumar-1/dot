module WError where
main = undefined
