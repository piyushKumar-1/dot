main :: IO Int
main = return $ sum [1,2,3]
