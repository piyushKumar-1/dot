module TypedHoles where
foo :: [Int] -> Int
foo x = _