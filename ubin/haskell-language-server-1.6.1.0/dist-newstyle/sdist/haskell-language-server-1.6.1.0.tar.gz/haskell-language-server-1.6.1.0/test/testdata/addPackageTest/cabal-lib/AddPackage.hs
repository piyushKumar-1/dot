module AddPackage where 

import Data.Text
foo = pack "I'm a Text"