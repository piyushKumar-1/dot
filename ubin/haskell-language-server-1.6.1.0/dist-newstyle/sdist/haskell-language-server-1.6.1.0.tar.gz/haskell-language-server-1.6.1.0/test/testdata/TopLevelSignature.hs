{-# OPTIONS_GHC -Wall #-}
module TopLevelSignature where
main = do
  putStrLn "Hello"
  return ()
