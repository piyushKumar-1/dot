main = butStrLn "hello"
foo = putStrn "world"
