module CodeActionOnly where
foo = bar
    where bar = id Nothing