module Bar where

a = 42
